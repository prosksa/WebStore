﻿using System.Collections.Generic;
using WebStore.Domain.Entities;
using WebStore.Domain.Filters;

namespace WebStore.Infrastructure.Interfaces
{
	/// <summary>
	/// Интерфейс для работы с товарами
	/// </summary>
	public interface IProductData
	{
		/// <summary>
		/// Список секций
		/// </summary>
		/// <returns></returns>
		IEnumerable<Section> GetSections();
		/// <summary>
		/// Список брендов
		/// </summary>
		/// <returns></returns>
		IEnumerable<Brand> GetBrands();
		/// <summary>
		/// Список товаров
		/// </summary>
		/// <param name="filter">Фильтр товаров</param>
		/// <returns></returns>
		IEnumerable<Product> GetProducts(ProductFilter filter);
		/// <summary>
		/// Продукт
		/// </summary>
		/// <param name="id">Идентификатор</param>
		/// <returns>Сущность Product, если нашёл, иначе null</returns>
		Product GetProductById(int id);
	}
}
